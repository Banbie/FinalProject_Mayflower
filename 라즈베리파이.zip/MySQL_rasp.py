import pymysql as sql


def insertData(io_id, date, time, prodnum, pronum):
    db = sql.connect(host="192.168.0.3", user="edu", password="1234", db="mayflower", charset="utf8")  # db에 접속!
    cursor = db.cursor()  # 객체생성

    query = "SELECT plannum from tb_plan where nowea < planea order by priority,duedate limit 1"  # tb_flow의 plannum에 넣을 값을 tb_plan에서 불러오기
    cursor.execute(query)
    re = cursor.fetchall()  # plannum을 re에 저장!

    query = "INSERT INTO tb_flow(io_id,flowdate,flowtime,plannum,prodnum,pronum) VALUES('%s','%s','%s', %s,'%s',%d);" % (
    io_id, date, time, re[0][0], prodnum, pronum)
    cursor.execute(query)  # tb_flow에 차례로 값 넣기~

    if pronum == 0:  # 맨 처음 공정이면
        query = "INSERT INTO tb_prod(lotnum) VALUES('%s');" % (prodnum)  # tb_prod에 값 넣기
        cursor.execute(query)

    db.commit()  # db에 적용
    db.close()  # db 닫기


def updateData(lotnum, filename, spec, proddate):  # tb_prod 업데이트

    db = sql.connect(host="192.168.0.3", user="edu", password="1234", db="mayflower", charset="utf8")  # 역시 db에 접속!
    cursor = db.cursor()  # 객체 생성

    query = "UPDATE tb_prod SET "  # 업데이트를 하는데
    where = " where lotnum = '%s'" % (lotnum)  # lotnum으로 prod 확인

    if filename != "":  # filename에 값이 있으면
        query += "filename = '%s'" % (filename)  # filename 업데이트
    elif spec != "":  # spec에 값이 있으면
        query += "spec = %s" % (spec)  # spec 업데이트
    elif proddate != "":  # proddate에 값이 있으면
        query += "proddate = '%s'" % (proddate)  # proddate 업데이트
    cursor.execute(query + where)  # 실행!
    db.commit()  # db에 적용!

    db.close()  # db 닫기