import time  # time.sleep 용
import datetime  # 날짜와 시간
from picamera import PiCamera  # 카메라&캡쳐
import threading as td  # 멀티 스레드
import RPi.GPIO as GPIO  # 센서, 모터
import pymcprotocol  # PLC 통신 mc프로토콜
import MySQL_rasp as sql  # MySQL
import pigpio  # 모터

pi = pigpio.pi()  # 모터
pi.set_servo_pulsewidth(21, 1000)  # 초기 셋팅(45도)

GPIO.setmode(GPIO.BCM)  # 센서 핀모드
GPIO.setwarnings(False)  # 오류방지

Sen1 = 17  # 첫번째 근접 센서. 투입되는 제품의 수를 세기 위한 센서
Sen2 = 27  # 카메라의 캡쳐를 위한 근접센서.

GPIO.setup(Sen1, GPIO.IN)  # input 모드
GPIO.setup(Sen2, GPIO.IN)

event = td.Event()  # 공정 정지를 위한 이벤트

camera = PiCamera()  # 이미지 인식을 위한 카메라
camera.sensor_mode = 2  # 프리뷰에 나오는 화면과 똑같이 캡쳐하기 위함(모드 1은 프리뷰에 나오지 않은 부분까지 확장해서 캡쳐됨)
camera.start_preview(fullscreen=False, window=(200, 200, 690, 460))  # 모니터 200,200에 가로 690 세로 460크기의 실시간 카메라 프리뷰창 띄우기
camera.resolution = (1035, 690)

pymc3e = pymcprotocol.Type3E()  # 미쯔비시 PLC 통신을 위한 mc프로토콜
pymc3e.setaccessopt(commtype="binary")  # 바이너리 타입
pymc3e.connect("192.168.3.39", 4005)  # PLC ip, port 번호로 연결

insum = pymc3e.batchread_wordunits(headdevice="D10", readsize=1)[0]  # 현재까지 투입된 제품 수 불러오기
print(insum)
insum2 = insum  # 판별과정용
insum3 = insum  # 분류과정용
print(insum)


def sumPrev():  # 첫번째 근접센서 작동 함수
    input_prev1 = 1  # 근접센서1 이전값
    global insum

    while 1:
        if event.is_set():  # PLC 비상정지 시, 'c' 입력시
            break  # while loop 종료

        in1 = GPIO.input(Sen1)  # 첫번째 근접센서 값
        if in1 == 1:  # 만약 센서에 물체가 근접하지 않으면
            input_prev1 = 1

        elif input_prev1 != in1:  # 센서에 물체가 근접하면
            insum += 1  # 제품 카운트 추가
            print(insum)
            pymc3e.batchwrite_wordunits(headdevice="D10", values=[insum])  # 카운트 적용
            prod = datetime.datetime.now().strftime('%m-%d_')  # sql을 위한 날짜값
        date1 = datetime.datetime.now().strftime('%Y-%m-%d')  # sql용 첫번째 날짜 저장
        time1 = datetime.datetime.now().strftime('%H:%M:%S')  # sql용 첫번째 시간 저장
        sql.insertData('PLC_m10', date1, time1, prod + str(insum), 0)  # 데이터 db(tb_flow,tb_prod)에 전송
        pymc3e.batchwrite_wordunits(headdevice="M10", values=[1])  # 1초동안 M10에 센서 bool값 전송
        time.sleep(1)
        pymc3e.batchwrite_wordunits(headdevice="M10", values=[0])
        input_prev1 = in1  # 한번만 실행하기 위함 - 물체 한개에 여러번 실행 방지
    time.sleep(0.25)  # while loop 메모리 초과 방지용


def sumRag():  # 두번째 근접센서 및 카메라 작동 함수
    input_prev2 = 0  # 근접센서2 이전값
    global insum2

    while 1:
        if event.is_set():  # PLC 비상정지 시, 'c' 입력시
            break  # while loop 종료

        in2 = GPIO.input(Sen2)  # 두번째 근접센서값
        if in2 == 0:
            input_prev2 = 0

        elif input_prev2 != in2:  # 두번째 근접센서에 물체가 근접하면
            insum2 += 1
        fname = datetime.datetime.now().strftime('%m-%d_')  # 이미지 저장을 위한 날짜값
        filename = '/home/pi/Pictures/' + fname + str(insum2) + '.jpg'
        camera.capture(filename, resize=(690, 460))  # 카메라 캡쳐
        date2 = datetime.datetime.now().strftime('%Y-%m-%d')  # sql용 두번째 날짜 저장
        time2 = datetime.datetime.now().strftime('%H:%M:%S')  # sql용 두번째 시간 저장
    sql.insertData('PLC_m11', date2, time2, fname + str(insum2), 1)  # 데이터 db(tb_flow)에 전송
    pymc3e.batchwrite_wordunits(headdevice="M11", values=[1])  # 근접센서 & 카메라 bool
    sql.updateData(fname + str(insum2), fname + str(insum2), "", "")  # tb_prod 업데이트!


time.sleep(1)  # while loop가 너무 빨리 돌아 PLC 데이터 전달이 무시되는 것을 방지
input_prev2 = in2  # 한번 실행~
time.sleep(0.2)  # 메모리 초과 방지~


def tensorMotor():  # 모터 작동 함수
    global insum3


while 1:
    if event.is_set():  # PLC 비상정지 시, 'c' 입력시
        break  # while loop 종료

    idenfy = pymc3e.batchread_wordunits(headdevice="D11", readsize=1)  # 합/불/대기판정 값 불러오기
    prod = datetime.datetime.now().strftime('%m-%d_')  # sql용
if idenfy == [2]:  # 합격이면
    insum3 += 1  # 분류과정용 +1
pymc3e.batchwrite_wordunits(headdevice="D12", values=[1])  # 모터 0도값 전송(1)
pi.set_servo_pulsewidth(21, 500)  # 모터 0도 작동
sql.updateData(prod + str(insum3), "", 2, "")  # tb_prod 업데이트~

elif idenfy == [1]:  # 불합격이면
pymc3e.batchwrite_wordunits(headdevice="D12", values=[0])  # 모터 36도값 전송(0)
pi.set_servo_pulsewidth(21, 900)  # 모터 36도 작동
sql.updateData(prod + str(insum3), "", 1, "")
if idenfy != [0]:  # 대기 상태가 아니면
    date3 = datetime.datetime.now().strftime('%Y-%m-%d')  # sql용 세번째 날짜 저장
    time3 = datetime.datetime.now().strftime('%H:%M:%S')  # sql용 세번째 시간 저장
    sql.insertData('PLC_d11', date3, time3, prod + str(insum3), 2)  # tb_flow 전송
    sql.updateData(prod + str(insum3), "", "", date3 + " " + time3)  # tb_prod 업데이트~
pymc3e.batchwrite_wordunits(headdevice="D11", values=[0])  # 대기 상태로 전환
time.sleep(0.8)
time.sleep(0.3)  # 메모리 초과 방지~

if __name__ == '__main__':
    proc1 = td.Thread(target=sumPrev, args=(), daemon=True)  # 멀티 스레드 1
    proc2 = td.Thread(target=sumRag, args=(), daemon=True)  # 멀티 스레드 2
    proc3 = td.Thread(target=tensorMotor, args=(), daemon=True)  # 멀티 스레드 3
    proc1.start()
    proc2.start()
    proc3.start()
    while 1:
        x = input("")  # 키보드 입력값
        if x == 'c':
            break  # 메인 while 루프 종료
        time.sleep(3)  # 메모리 용량 초과 방지~

pymc3e.batchwrite_wordunits(headdevice="M10", values=[0])  # 첫번재 근접센서 off값 전송
event.set()  # 스레드 안의 무한 whiile loop 종료
camera.close()  # 카메라 닫기
pymc3e.close()  # PLC 연결 종료
GPIO.cleanup()  # GPIO 리소스 청소~
print("end")  # 끝!